Hello World
<?php phpinfo() ?>